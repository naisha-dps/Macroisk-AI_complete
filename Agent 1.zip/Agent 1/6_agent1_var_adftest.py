import pandas as pd
import numpy as np
import os
import joblib
from statsmodels.tsa.api import VAR

def train_var_model():
    """Trains Vector Autoregression (VAR) model for Agent 1 multivariate macro analysis."""
    database_path = "C:/Users/prana/Downloads/master_macro_dataset.csv"
    if not os.path.exists(database_path):
        raise FileNotFoundError(f"Master dataset not found at {database_path}.")

    df = pd.read_csv(database_path)

    df['Date'] = pd.to_datetime(
        df['Date'],
        format="%d/%m/%Y"
    )

    df = df.set_index("Date")
    df = df.asfreq("MS")

    # Select key endogenous variables for multivariate feedback loops
    vars_to_use = ['CPI_Inflation_Rate', 'WPI', 'Repo_Rate', 'oil_price', 'exchange_rate']
    model_df = df[vars_to_use].dropna()
    model_df = model_df.diff(12).dropna() 

    from statsmodels.tsa.stattools import adfuller

    for col in model_df.columns:
        result = adfuller(model_df[col])

        print(f"\n{col}")
        print(f"ADF Statistic : {result[0]:.4f}")
        print(f"p-value       : {result[1]:.4f}")


if __name__ == "__main__":
    train_var_model()
